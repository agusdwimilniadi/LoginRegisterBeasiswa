import React from "react";
import { Link, useLocation } from "react-router-dom";

export default function Navbar() {
  const location = useLocation();
  const getNavLinkClass = (path) => {
    return location.pathname === path ? "active" : "";
  };
  return (
    <>
      <div
        className=""
        style={{ backgroundColor: "#353381", borderRadius: "20px" }}
      >
        {/* eslint-disable */}
        <nav
          className="container navbar navbar-expand-lg navbar-light"
          style={{ padding: "1rem 5px !important", zIndex: "10" }}
        >
          <a href="#"></a>
          <button
            className="navbar-toggler border-0"
            type="button"
            data-bs-toggle="modal"
            data-bs-target="#targetModal-item"
          >
            <span className="navbar-toggler-icon" />
          </button>
          <div
            className="modal-item modal fade"
            id="targetModal-item"
            tabIndex={-1}
            role="dialog"
            aria-labelledby="targetModalLabel"
            aria-hidden="true"
          >
            <div className="modal-dialog" role="document">
              <div className="modal-content bg-darks border-0">
                <div
                  className="modal-header border-0"
                  style={{ padding: "2rem", paddingBottom: 0 }}
                >
                  <a className="modal-title" id="targetModalLabel"></a>
                  <button
                    type="button"
                    className="close btn-close text-white"
                    data-bs-dismiss="modal"
                    aria-label="Close"
                  />
                </div>
                <div
                  className="modal-body"
                  style={{ padding: "2rem", paddingTop: 0, paddingBottom: 0 }}
                >
                  <ul className="navbar-nav responsive me-auto mt-2 mt-lg-0">
                    <li
                      className={`nav-item ${getNavLinkClass(
                        "/"
                      )} position-relative px-0`}
                    >
                      <Link className="nav-link fs-6  main text-white" to="/">
                        <button className="btn btn-transparent p-0 text-white">
                          Home
                        </button>
                      </Link>
                    </li>

                    <li
                      className={`nav-item ${getNavLinkClass(
                        "/browse/sintesis"
                      )} ${getNavLinkClass(
                        "/browse/herbal"
                      )}  position-relative px-0`}
                    >
                      <div className="btn-group">
                        <button
                          type="button"
                          className="btn btn-transparent text-white p-0 dropdown-toggle"
                          data-bs-toggle="dropdown"
                          aria-expanded="false"
                        >
                          Browse
                        </button>
                        <ul className="dropdown-menu">
                          <li>
                            <a className="dropdown-item" href="/browse/herbal">
                              Senyawa Herbal
                            </a>
                          </li>
                          <li>
                            <a
                              className="dropdown-item"
                              href="/browse/sintesis"
                            >
                              Senyawa Sintesis
                            </a>
                          </li>
                        </ul>
                      </div>
                    </li>
                    <li
                      className={`nav-item ${getNavLinkClass(
                        "/terbaru"
                      )} position-relative px-0`}
                    >
                      <Link
                        className="nav-link fs-6  main text-white"
                        to="/terbaru"
                      >
                        <button className="btn btn-transparent p-0 text-white">
                          Data Terbaru
                        </button>
                      </Link>
                    </li>
                    <li
                      className={`nav-item ${getNavLinkClass(
                        "/spektra"
                      )} position-relative px-0`}
                    >
                      <Link className="nav-link fs-6" to="/spektra">
                        <button className="btn btn-transparent  p-0 text-white">
                          Spektra IR
                        </button>
                      </Link>
                    </li>
                    <li
                      className={`nav-item ${getNavLinkClass(
                        "/products"
                      )} position-relative px-0`}
                    >
                      <Link className="nav-link fs-6" to="/products">
                        <button className="btn btn-transparent  p-0 text-white">
                          Product
                        </button>
                      </Link>
                    </li>
                    <li
                      className={`nav-item ${getNavLinkClass(
                        "/news"
                      )} position-relative px-0`}
                    >
                      <Link className="nav-link fs-6" to="/news">
                        <button className="btn btn-transparent  p-0 text-white">
                          News
                        </button>
                      </Link>
                    </li>
                    <li
                      className={`nav-item ${getNavLinkClass(
                        "/galery"
                      )} position-relative px-0`}
                    >
                      <Link className="nav-link fs-6" to="/galery">
                        <button className="btn btn-transparent p-0 text-white">
                          Gallery
                        </button>
                      </Link>
                    </li>
                    <li
                      className={`nav-item ${getNavLinkClass(
                        "/about-us"
                      )} position-relative px-0 `}
                    >
                      <Link className="nav-link fs-6" to="/about-us">
                        <button className="btn btn-transparent p-0 text-white ">
                          About Us
                        </button>
                      </Link>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <div className="collapse navbar-collapse" id="navbarTogglerDemo">
            <ul className="navbar-nav mx-auto mt-2 mt-lg-0">
              <li
                className={`nav-item ${getNavLinkClass("/")} position-relative`}
              >
                <Link className="nav-link fs-6  main text-white" to="/">
                  <button className="btn btn-transparent p-0 text-white">
                    Home
                  </button>
                </Link>
              </li>

              <li
                className={`nav-item ${getNavLinkClass(
                  "/browse/sintesis"
                )} ${getNavLinkClass("/browse/herbal")}  position-relative`}
              >
                <div className="btn-group">
                  <button
                    type="button"
                    className="btn btn-transparent text-white p-0 dropdown-toggle"
                    data-bs-toggle="dropdown"
                    aria-expanded="false"
                  >
                    Browse
                  </button>
                  <ul className="dropdown-menu">
                    <li>
                      <a className="dropdown-item" href="/browse/herbal">
                        Senyawa Herbal
                      </a>
                    </li>
                    <li>
                      <a className="dropdown-item" href="/browse/sintesis">
                        Senyawa Sintesis
                      </a>
                    </li>
                  </ul>
                </div>
              </li>
              <li
                className={`nav-item ${getNavLinkClass(
                  "/terbaru"
                )} position-relative px-0`}
              >
                <Link className="nav-link fs-6  main text-white" to="/terbaru">
                  <button className="btn btn-transparent p-0 text-white">
                    Data Terbaru
                  </button>
                </Link>
              </li>
              <li
                className={`nav-item ${getNavLinkClass(
                  "/spektra"
                )} position-relative px-0`}
              >
                <Link className="nav-link fs-6" to="/spektra">
                  <button className="btn btn-transparent  p-0 text-white">
                    Spektra IR
                  </button>
                </Link>
              </li>
              <li
                className={`nav-item ${getNavLinkClass(
                  "/products"
                )} position-relative px-0`}
              >
                <Link className="nav-link fs-6" to="/products">
                  <button className="btn btn-transparent  p-0 text-white">
                    Product
                  </button>
                </Link>
              </li>
              <li
                className={`nav-item ${getNavLinkClass(
                  "/news"
                )} position-relative`}
              >
                <Link className="nav-link fs-6" to="/news">
                  <button className="btn btn-transparent  ms-2 p-0 text-white">
                    News
                  </button>
                </Link>
              </li>
              <li
                className={`nav-item ${getNavLinkClass(
                  "/galery"
                )} position-relative`}
              >
                <Link className="nav-link fs-6" to="/galery">
                  <button className="btn btn-transparent p-0 text-white">
                    Gallery
                  </button>
                </Link>
              </li>
              <li
                className={`nav-item ${getNavLinkClass(
                  "/about-us"
                )} position-relative`}
              >
                <Link className="nav-link fs-6" to="/about-us">
                  <button className="btn btn-transparent p-0 text-white">
                    About Us
                  </button>
                </Link>
              </li>
            </ul>
          </div>
        </nav>
      </div>
    </>
  );
}
