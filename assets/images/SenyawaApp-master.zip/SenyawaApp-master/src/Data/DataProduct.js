let dataProduct = [
  {
    id: 1,
    linkVideo: "https://youtu.be/qYLvY-G2arc",
    judulVideo: "Judul Lorem ipsum1",
    desc: "Lorem ipsum",
  },
  {
    id: 2,
    linkVideo: "https://youtu.be/LfgNNF7OzFY",
    judulVideo: "Judul Lorem ipsum2",
    desc: "Lorem ipsum",
  },
  {
    id: 3,
    linkVideo: "https://youtu.be/qYLvY-G2arc",
    judulVideo: "Judul Lorem ipsum3",
    desc: "Lorem ipsum",
  },
  {
    id: 4,
    linkVideo: "https://youtu.be/qYLvY-G2arc",
    judulVideo: "Judul Lorem ipsum",
    desc: "Lorem ipsum",
  },
];
export default dataProduct;
