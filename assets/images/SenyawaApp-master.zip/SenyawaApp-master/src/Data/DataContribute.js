let dataJabatan = {
  data: [
    {
      nama: "Muhammad Irawan",
      role: "Designer",
      dataAnggota: [
        {
          nama: "",
          email: "",
        },
        {
          nama: "abcdefgh",
          email: "abgcefgh@gmail.com",
        },
        {
          nama: "abcdefgh",
          email: "abgcefgh@gmail.com",
        },
      ],
    },
    {
      nama: "Muhammad Setiadi",
      role: "Data Input",
      dataAnggota: [],
    },
    {
      nama: "Muhammad Wawan",
      role: "Shorting",
      dataAnggota: [
        {
          nama: "abcdefgh",
          email: "abgcefgh@gmail.com",
        },
        {
          nama: "abcdefgh",
          email: "abgcefgh@gmail.com",
        },
        {
          nama: "abcdefgh",
          email: "abgcefgh@gmail.com",
        },
      ],
    },
  ],
};
export default dataJabatan;
