let dataVideo = [
  {
    senyawa: "air",
    videoData: [
      {
        v: "1713.25",
        i: "75.739",
        video:
          "https://firebasestorage.googleapis.com/v0/b/senyawa-49872.appspot.com/o/spektra%2Fair%2F1.gif?alt=media&token=bdcfb467-b739-42e3-aecc-1dbf41fb63b1",
      },
      {
        v: "3729.65",
        i: "1.698",
        video:
          "https://firebasestorage.googleapis.com/v0/b/senyawa-49872.appspot.com/o/spektra%2Fair%2F2.gif?alt=media&token=d09ac160-a6d1-43e9-9c3d-4d892154be05",
      },
      {
        v: "3729.65",
        i: "1.698",
        video:
          "https://firebasestorage.googleapis.com/v0/b/senyawa-49872.appspot.com/o/spektra%2Fair%2F3.gif?alt=media&token=dfad06e5-e3ee-4046-86f6-092c2235cd2d",
      },
    ],
    linkSpektra:
      "https://firebasestorage.googleapis.com/v0/b/senyawa-49872.appspot.com/o/spektra%2Fair%2Fir.png?alt=media&token=1891c3ed-f65a-4df5-be58-da4265913054",
    linkOutput:
      "https://firebasestorage.googleapis.com/v0/b/senyawa-49872.appspot.com/o/spektra%2Fair%2Fair.out?alt=media&token=13d16232-27f1-472d-9c93-58c0de2a4a67",
  },
  {
    senyawa: "ccl4",
    videoData: [
      {
        v: "218.69",
        i: "0.000",
        video:
          "https://firebasestorage.googleapis.com/v0/b/senyawa-49872.appspot.com/o/spektra%2Fccl4%2F1.gif?alt=media&token=55272e33-c99a-472c-ab7a-d45ed6ac1f4c",
      },
      {
        v: "218.69",
        i: "0.000",
        video:
          "https://firebasestorage.googleapis.com/v0/b/senyawa-49872.appspot.com/o/spektra%2Fccl4%2F2.gif?alt=media&token=4a25c43e-7b7d-450d-bdf9-8de2cf2e6171",
      },
      {
        v: "315.87",
        i: "0.167",
        video:
          "https://firebasestorage.googleapis.com/v0/b/senyawa-49872.appspot.com/o/spektra%2Fccl4%2F3.gif?alt=media&token=84f8daa1-b36b-4d77-822f-5e991d481b81",
      },
      {
        v: "316.05",
        i: "0.154",
        video:
          "https://firebasestorage.googleapis.com/v0/b/senyawa-49872.appspot.com/o/spektra%2Fccl4%2F4.gif?alt=media&token=039a2d42-ffc6-40c2-a93c-67c4ed6bd65d",
      },
      {
        v: "316.11",
        i: "0.163",
        video:
          "https://firebasestorage.googleapis.com/v0/b/senyawa-49872.appspot.com/o/spektra%2Fccl4%2F5.gif?alt=media&token=1973f465-61e5-45d2-bfa6-d6e2d5258db1",
      },
      {
        v: "451.40",
        i: "0.000",
        video:
          "https://firebasestorage.googleapis.com/v0/b/senyawa-49872.appspot.com/o/spektra%2Fccl4%2F6.gif?alt=media&token=55f1b70d-64a2-4c91-b4df-9c0b9613ffac",
      },
      {
        v: "748.30",
        i: "203.175",
        video:
          "https://firebasestorage.googleapis.com/v0/b/senyawa-49872.appspot.com/o/spektra%2Fccl4%2F7.gif?alt=media&token=31354930-d85c-423a-b34a-cd6a620f51bd",
      },
      {
        v: "748.91",
        i: "202.940",
        video:
          "https://firebasestorage.googleapis.com/v0/b/senyawa-49872.appspot.com/o/spektra%2Fccl4%2F8.gif?alt=media&token=de7b8a86-d26a-4ff9-8972-788f39aea24c",
      },
      {
        v: "749.01",
        i: "203.042",
        video: "https://www.youtube.com/watch?v=3wFcnrLT83M",
      },
    ],
    linkSpektra:
      "https://firebasestorage.googleapis.com/v0/b/senyawa-49872.appspot.com/o/spektra%2Fccl4%2Fir.png?alt=media&token=cc24b7de-a3bf-4af8-a74b-b6714dfaa37a",
    linkOutput:
      "https://firebasestorage.googleapis.com/v0/b/senyawa-49872.appspot.com/o/spektra%2Fccl4%2Fccl4.out?alt=media&token=d6c4876e-2056-4ffe-b671-f815ae765347",
  },
];

export default dataVideo;
