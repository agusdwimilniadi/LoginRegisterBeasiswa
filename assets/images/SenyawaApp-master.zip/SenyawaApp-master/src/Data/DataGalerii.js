let dataimage = {
  carousel: [
    {
      id: 1,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2F20220122_174518.webp?alt=media&token=4e9d7f90-67b6-4f6f-8268-508f1dc6473b",
    },
    {
      id: 2,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2F20220122_174604.webp?alt=media&token=a76f786d-c645-4fbf-83f2-4989391f183d",
    },
    {
      id: 3,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2F20220122_174619.webp?alt=media&token=94c4ecf4-3232-4dc7-99b6-951ee16ca4c6",
    },
  ],
  images: [
    {
      id: 1,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2F20220122_174518.webp?alt=media&token=4e9d7f90-67b6-4f6f-8268-508f1dc6473b",
    },
    {
      id: 2,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2F20220122_174604.webp?alt=media&token=a76f786d-c645-4fbf-83f2-4989391f183d",
    },
    {
      id: 3,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2F20220122_174619.webp?alt=media&token=94c4ecf4-3232-4dc7-99b6-951ee16ca4c6",
    },
    {
      id: 4,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2F20220122_195823.webp?alt=media&token=64618b78-96fb-4be3-8d63-1f7cd29b0498",
    },
    {
      id: 5,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2F20220122_200836.webp?alt=media&token=a8a044ee-6b80-4bfd-9187-f17dee38f508",
    },
    {
      id: 6,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2F20220123_060446.webp?alt=media&token=da2220db-36af-455b-955b-0d4557f7fa61",
    },
    {
      id: 7,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2F20220123_060459.webp?alt=media&token=714a0180-bc9c-4c04-b024-f05297d3cb38",
    },
    {
      id: 8,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2F20220123_060747.webp?alt=media&token=48112394-658d-4374-b221-807ca3fbafb4",
    },
    {
      id: 9,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2F20220123_060827.webp?alt=media&token=9352a95a-469b-4780-aa13-a20550f5a5dd",
    },
    {
      id: 10,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2F20220123_060850.webp?alt=media&token=f9bb1ce9-7ea0-473c-a357-72782c2ac0d7",
    },
    {
      id: 11,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2F20220123_060909.webp?alt=media&token=c73f8c56-c9b4-4aa6-8586-58f02ce66aa3",
    },
    {
      id: 12,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2F20220123_060915.webp?alt=media&token=b8ea1f02-cbcc-4a87-96f2-7bf506312389",
    },
    {
      id: 13,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2F20220123_060932.webp?alt=media&token=22f7d1cc-d7bb-4f11-9e9e-eca01f1258bc",
    },
    {
      id: 14,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2F20220123_060949.webp?alt=media&token=068c38cd-3fa8-47bf-85ee-e026aa68dba6",
    },
    {
      id: 15,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2F20220123_060957.webp?alt=media&token=b7783761-bf88-4e8c-bcb5-ff9f8e2805c9",
    },
    {
      id: 16,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2F20220123_061810.webp?alt=media&token=f9552c4f-d2d4-43f1-96f7-f5a570471317",
    },
    {
      id: 17,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2F20220123_061814.webp?alt=media&token=255494f3-c447-4733-899d-38dbe56e728a",
    },
    {
      id: 18,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2F20220123_061836.webp?alt=media&token=5daf4932-f28c-438b-b00c-7cc5530d433b",
    },
    {
      id: 19,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2F20220123_061842.webp?alt=media&token=cc9eee71-72e9-423d-ae78-78fb4efc5b1f",
    },
    {
      id: 20,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2F20220123_062847.webp?alt=media&token=9a0cdaa5-dc48-43f1-b558-2e469ee78d56",
    },
    {
      id: 21,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2F20220123_062857.webp?alt=media&token=98f65069-6c4b-46ee-abf0-e3b44086aae3",
    },
    {
      id: 22,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2F20220123_063322.webp?alt=media&token=c70f0fef-b096-4c81-8f4c-d17639014a2b",
    },
    {
      id: 23,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2F20220123_070030.webp?alt=media&token=81cf6360-271a-49fe-acb7-013fa131a435",
    },
    {
      id: 24,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2F20220123_070035.webp?alt=media&token=3fc6f015-c52c-47d8-aad2-a5fdbf938297",
    },
    {
      id: 25,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2F20220123_070232.webp?alt=media&token=52c70286-808e-4298-bba9-5a04884af200",
    },
    {
      id: 26,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2F20220123_070325.webp?alt=media&token=a5999ae1-0dc5-45a4-a16f-a86a90cbee56",
    },
    {
      id: 27,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2F20220123_070348.webp?alt=media&token=b23154a2-4649-4419-a27f-feab90a51d4f",
    },
    {
      id: 28,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2F20220123_070827.webp?alt=media&token=5d09fe84-6c9f-43c6-a111-408c8aafc96e",
    },
    {
      id: 29,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2F20220123_080511.webp?alt=media&token=737bbc69-2343-45c8-b3ec-5692d385b742",
    },
    {
      id: 30,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2F20220123_080543.webp?alt=media&token=d001a0bd-b169-46d0-b1b6-710268f71f05",
    },
    {
      id: 31,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2F20220123_080548.webp?alt=media&token=6fb2358e-a5a3-4c2b-8680-d758bf989533",
    },
    {
      id: 32,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2F20220123_080613.webp?alt=media&token=51aec0d9-40df-46d9-a1f4-0d739a865c64",
    },
    {
      id: 33,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2F20220123_080621.webp?alt=media&token=696c392d-23f2-4356-b5a9-668bd6c7b3b3",
    },
    {
      id: 34,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2F20220123_080832.webp?alt=media&token=e9ea6bb3-fa53-4f9f-a58d-fe4f4f2f02f7",
    },
    {
      id: 35,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2F20220123_080919.webp?alt=media&token=9f488342-1fef-43cb-9ec4-67e849d3e84d",
    },
    {
      id: 36,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2F20220123_080929.webp?alt=media&token=03bc9e18-b2d4-4883-a6d2-ddd4e2d052f2",
    },
    {
      id: 37,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2F20220123_081000.webp?alt=media&token=f57bee95-6787-42c2-b1d5-e4bf1f814418",
    },
    {
      id: 38,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2F20220123_081312.webp?alt=media&token=9b906012-1085-4eb9-b7c1-c42669c3b9d9",
    },
    {
      id: 39,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2F20220123_082441.webp?alt=media&token=363d0c9a-892d-4819-ac0d-f20715fe142b",
    },
    {
      id: 40,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2F20220123_082515.webp?alt=media&token=51d82327-6d11-4bf9-b95e-0978c2b8851d",
    },
    {
      id: 41,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2F20220123_112853.webp?alt=media&token=8c2b419f-fa60-4367-a6f9-41e4333387d7",
    },
    {
      id: 42,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2FIMG20220122083917.webp?alt=media&token=e43d57da-bf8d-4faf-a880-d77367a35f6d",
    },
    {
      id: 43,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2FIMG20220122083953.webp?alt=media&token=8e1c33bc-fbf8-4a3a-84f2-8ef8059ca83e",
    },
    {
      id: 44,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2FIMG20220122084010.webp?alt=media&token=6413eb14-bfff-43db-bb18-a1c96489f270",
    },
    {
      id: 45,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2FIMG20220122084121.webp?alt=media&token=abc3a3d4-f91b-49d3-bf0e-bbb08dbabd3f",
    },
    {
      id: 46,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2FIMG20220122084136.webp?alt=media&token=c5f06ec7-a84b-4e16-a32f-a5a5026fe0c4",
    },
    {
      id: 47,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2FIMG20220122084702.webp?alt=media&token=acc640a1-31a8-48b3-bff7-b7fc51888f56",
    },
    {
      id: 48,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2FIMG20220122084719.webp?alt=media&token=ae80bccd-2ec0-4994-9504-88bfcd00265d",
    },
    {
      id: 49,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2FIMG20220122084756.webp?alt=media&token=237a127d-5889-4409-8c69-c81dfdca74f3",
    },
    {
      id: 50,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2FIMG20220122084823.webp?alt=media&token=45a02693-27d0-4b96-a749-bfbaffce8103",
    },
    {
      id: 51,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2FIMG20220122084827.webp?alt=media&token=7b71dd06-bd01-4fe2-8f74-08bf8cb0bcba",
    },
    {
      id: 52,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2FIMG20220122085105.webp?alt=media&token=d83824b5-69ac-4288-988b-9694dcb24fd3",
    },
    {
      id: 53,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2FIMG20220122085305.webp?alt=media&token=ae33cd2a-73d1-45f9-91fe-cbd7323057c2",
    },
    {
      id: 54,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2FIMG20220122085337.webp?alt=media&token=4592ba25-3364-47fc-b0f0-8cf9477dd2a9",
    },
    {
      id: 55,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2FIMG20220122094605.webp?alt=media&token=3c3fe12e-507e-44e1-a528-61e1d9f6acfb",
    },
    {
      id: 56,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2FIMG20220122094625.webp?alt=media&token=c4a3bc37-c18b-4a3d-a500-ee2db695e25c",
    },
    {
      id: 57,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2FIMG20220122094631.webp?alt=media&token=2c068abd-5930-4042-842b-4afea903cba1",
    },
    {
      id: 58,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2FIMG20220122094755.webp?alt=media&token=03eeee2d-d808-4944-93fc-998e54d2785d",
    },
    {
      id: 59,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2FIMG20220122094926.webp?alt=media&token=c0e52148-1547-46b2-95ef-7992d5602d1f",
    },
    {
      id: 60,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2FIMG20220122094932.webp?alt=media&token=73bcd777-ddaa-4f28-a3d0-5346b44353bc",
    },
    {
      id: 61,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2FIMG20220122094953.webp?alt=media&token=7adb082e-6397-4b31-82a5-f1f2fee3f3e6",
    },
    {
      id: 62,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2FIMG20220122095322.webp?alt=media&token=48bb732a-98cc-44bc-81a1-f7623ff8cf9c",
    },
    {
      id: 63,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2FIMG20220122095353.webp?alt=media&token=e9ab9e5a-6c88-457d-9065-30b8d36d5f87",
    },
    {
      id: 64,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2FIMG20220122095839.webp?alt=media&token=cf94e31e-4ed2-4559-aa60-7058c3332708",
    },
    {
      id: 65,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2FIMG20220122100022.webp?alt=media&token=021379ff-b45a-44cb-9006-b2ccd5958cd5",
    },
    {
      id: 66,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2FIMG20220122100032.webp?alt=media&token=ed4a8123-bd01-4f85-b73f-ff7d10021dca",
    },
    {
      id: 67,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2FIMG20220122100340.webp?alt=media&token=81a2558c-7f56-4c0f-b7f3-c47870409792",
    },
    {
      id: 68,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2FIMG20220122100458.webp?alt=media&token=e68ccdb4-d056-4909-bbb9-d55e59489bd6",
    },
    {
      id: 69,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2FIMG20220122100529.webp?alt=media&token=a7314906-4b6a-4f77-87e1-23ef23b0fae7",
    },
    {
      id: 70,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2FIMG20220122101055.webp?alt=media&token=bf74f0d6-8377-42f0-9d10-b87376edd664",
    },
    {
      id: 71,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2FIMG20220122101122.webp?alt=media&token=dc6e9e8a-dc8e-4c0f-a447-ee3e88b65922",
    },
    {
      id: 72,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2FIMG20220122101404.webp?alt=media&token=984fdf5b-e229-472a-8af1-14dafad092c4",
    },
    {
      id: 73,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2FIMG20220122101406.webp?alt=media&token=1bbe204b-be41-4b78-9bf2-e5bfd582cd01",
    },
    {
      id: 74,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2FIMG20220122101733.webp?alt=media&token=6b020d46-f160-4c3d-8092-c489c3c007e3",
    },
    {
      id: 75,
      url: "https://firebasestorage.googleapis.com/v0/b/investa-image-upload.appspot.com/o/SenyawaApp%2FSenyawa%2FIMG20220122101744.webp?alt=media&token=63d23ccb-a5c0-4c32-b55f-b24d7d6a9b90",
    },
  ],
};

export default dataimage;
