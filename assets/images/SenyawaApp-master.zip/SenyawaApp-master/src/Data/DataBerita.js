let dataBerita = [
  {
    image: "https://ubaya.ac.id/2018/up/berita/3638_20220421132249.png",
    url: "https://ubaya.ac.id/2018/content/news_detail/3638/Bincang-Kesehatan-Mental-2022--Bedakan-Produktivitas-dan-Toxic-Productivity.html",
    judul:
      "Bincang Kesehatan Mental 2022: Bedakan Produktivitas dan Toxic Productivity",
    judul_url:
      "https://ubaya.ac.id/2018/content/news_detail/3638/Bincang-Kesehatan-Mental-2022--Bedakan-Produktivitas-dan-Toxic-Productivity.html",
    desc: "Fakultas Psikologi Universitas Surabaya (Ubaya) mengadakan webinar Bincang Kesehatan Mental 2022...",
  },
  {
    image: "https://ubaya.ac.id/2018/up/berita/3637_20220420165747.png",
    url: "https://ubaya.ac.id/2018/content/news_detail/3637/Sharing-Alumni--Tren-Membangun-Startup.html",
    judul: "Sharing Alumni: Tren Membangun Startup",
    judul_url:
      "https://ubaya.ac.id/2018/content/news_detail/3637/Sharing-Alumni--Tren-Membangun-Startup.html",
    desc: "Komunitas Startup Universitas Surabaya (Ubaya) mengikuti webinar Sharing Alumni...",
  },
  {
    image: "https://ubaya.ac.id/2018/up/berita/3634_20220419231122.jpg",
    url: "https://ubaya.ac.id/2018/content/news_detail/3634/Ubaya-Adakan-Sosialisasi-Guru-Bimbingan-Konseling-SMA-se-Jawa-Timur.html",
    judul:
      "Ubaya Adakan Sosialisasi Guru Bimbingan Konseling SMA se-Jawa Timur",
    judul_url:
      "https://ubaya.ac.id/2018/content/news_detail/3634/Ubaya-Adakan-Sosialisasi-Guru-Bimbingan-Konseling-SMA-se-Jawa-Timur.html",
    desc: "Memperkenalkan program-program studi dan beasiswa, Ubaya mengundang guru bimbingan konseling...",
  },
  {
    image: "https://ubaya.ac.id/2018/up/berita/3633_20220419231017.jpg",
    url: "https://ubaya.ac.id/2018/content/news_detail/3633/FIK-Ubaya-Gelar-Pagelaran-Graduation-Show-Bertema-Nostalgia.html",
    judul: "FIK Ubaya Gelar Pagelaran Graduation Show Bertema Nostalgia",
    judul_url:
      "https://ubaya.ac.id/2018/content/news_detail/3633/FIK-Ubaya-Gelar-Pagelaran-Graduation-Show-Bertema-Nostalgia.html",
    desc: "Para mahasiswa Fakultas Industri Kreatif Universitas Surabaya (FIK Ubaya) lulus dengan menghasilkan adikarya....",
  },
  {
    image: "https://ubaya.ac.id/2018/up/berita/3631_20220418102448.jpg",
    url: "https://ubaya.ac.id/2018/content/news_detail/3631/Semarak-Dies-Natalis-Fakultas-Kedokteran-Ubaya-ke-6.html",
    judul: "Semarak Dies Natalis Fakultas Kedokteran Ubaya ke-6",
    judul_url:
      "https://ubaya.ac.id/2018/content/news_detail/3631/Semarak-Dies-Natalis-Fakultas-Kedokteran-Ubaya-ke-6.html",
    desc: "Fakultas Kedokteran Universitas Surabaya (FK Ubaya) telah memasuki usianya yang ke-6 tahun....",
  },
  {
    image: "https://ubaya.ac.id/2018/up/berita/3630_20220418101721.jpg",
    url: "https://ubaya.ac.id/2018/content/news_detail/3630/Kurikulum-Merdeka--Upaya-Meningkatkan-Kualitas-dan-Mengikis-Kesenjangan-Pendidikan-Indonesia.html",
    judul:
      "Kurikulum Merdeka: Upaya Meningkatkan Kualitas dan Mengikis Kesenjangan Pendidikan Indonesia",
    judul_url:
      "https://ubaya.ac.id/2018/content/news_detail/3630/Kurikulum-Merdeka--Upaya-Meningkatkan-Kualitas-dan-Mengikis-Kesenjangan-Pendidikan-Indonesia.html",
    desc: "Anindito Aditomo, S.Psi., M.Phil., Ph.D,, Kepala Badan Penelitian dan Pengembangan dan Perbukuan, Kementerian Pendidikan dan Kebudayaan RI menjadi pemateri di Seminar Nasional yang diadakan oleh Ubaya...",
  },
  {
    image: "https://ubaya.ac.id/2018/up/berita/3628_20220414204931.png",
    url: "https://ubaya.ac.id/2018/content/news_detail/3628/Komitmen-Penuh-Cegah-dan-Tangani-Kekerasan-Seksual--Ubaya-Bentuk-Satuan-Tugas-Khusus.html",
    judul:
      "Komitmen Penuh Cegah dan Tangani Kekerasan Seksual, Ubaya Bentuk Satuan Tugas Khusus",
    judul_url:
      "https://ubaya.ac.id/2018/content/news_detail/3628/Komitmen-Penuh-Cegah-dan-Tangani-Kekerasan-Seksual--Ubaya-Bentuk-Satuan-Tugas-Khusus.html",
    desc: "Universitas Surabaya (Ubaya) berkomitmen penuh untuk menjamin atmosfir pembelajaran yang nyaman dan aman....",
  },
  {
    image: "https://ubaya.ac.id/2018/up/berita/3626_20220413205551.jpg",
    url: "https://ubaya.ac.id/2018/content/news_detail/3626/Diskusi-Preparing-for-the-Future--Bahas-Tantangan-Perguruan-Tinggi-Kedepan.html",
    judul:
      "Diskusi Preparing for the Future, Bahas Tantangan Perguruan Tinggi Kedepan",
    judul_url:
      "https://ubaya.ac.id/2018/content/news_detail/3626/Diskusi-Preparing-for-the-Future--Bahas-Tantangan-Perguruan-Tinggi-Kedepan.html",
    desc: "Ubaya menghadirkan Prof. Dr. Satryo Soemantri Brodjonegoro, selaku Ketua Akademi Ilmu Pengetahuan Indonesia (AIPI)...",
  },
  {
    image: "https://ubaya.ac.id/2018/up/berita/3625_20220412092324.jpg",
    url: "https://ubaya.ac.id/2018/content/news_detail/3625/Ubaya-Tandatangani-MoU-Matching-Fund-dengan-PT-Komunal-Sejahtera-Indonesia.html",
    judul:
      "Ubaya Tandatangani MoU Matching Fund dengan PT Komunal Sejahtera Indonesia",
    judul_url:
      "https://ubaya.ac.id/2018/content/news_detail/3625/Ubaya-Tandatangani-MoU-Matching-Fund-dengan-PT-Komunal-Sejahtera-Indonesia.html",
    desc: "Ubaya bekerjasama dengan startup untuk mengoptimalkan implementasi program Merdeka Belajar-Kampus Merdeka (MBKM)...",
  },
  {
    image: "https://ubaya.ac.id/2018/up/berita/3623_20220408153309.jpg",
    url: "https://ubaya.ac.id/2018/content/news_detail/3623/Ubaya-Ajak-SMK-Harapan-Sejati-Keliling-Fakultas-Teknik.html",
    judul: "Ubaya Ajak SMK Harapan Sejati Keliling Fakultas Teknik",
    judul_url:
      "https://ubaya.ac.id/2018/content/news_detail/3623/Ubaya-Ajak-SMK-Harapan-Sejati-Keliling-Fakultas-Teknik.html",
    desc: "Universitas Surabaya (Ubaya) kedatangan siswa-siswi dari SMK Kristen Harapan Sejati Surabaya....",
  },
];
export default dataBerita;
