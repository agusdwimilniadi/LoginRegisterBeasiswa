import "./App.css";
import Content from "./Components/Content";
import Navbar from "./Navbar";
import { Route, Routes } from "react-router-dom";
import Datacontent from "./Components/DataContent/DataContent";
import NotFound from "./Pages/NotFound";
import HeaderUbaya from "./Components/HeaderUbaya/HeaderUbaya";
import DetailData from "./Pages/DetailData";
import Browse from "./Pages/Browse";
import Berita from "./Pages/Berita";
import AboutUs from "./Pages/AboutUs";
import FooterUbaya from "./Components/Footer/FooterUbaya";
import DataSenyawa from "./Components/DataContent/DataSenyawa";
import BrowseSintesis from "./Pages/BrowseSintesis";
import DetailSenyawa from "./Pages/DetailSenyawa";
import Gallery from "./Pages/Gallery";
import Contribute from "./Pages/Contribute";
import Spektra from "./Pages/Spektra";
import Detailspektra from "./Pages/DetailSpektra";
import AllGaleri from "./Pages/AllGaleri";
import TerbaruTanaman from "./Pages/TerbaruTanaman";
import ProductPage from "./Pages/ProductPage";
import DetailVideo from "./Pages/DetailVideo";

function App() {
  return (
    <>
      <div
        className=" mx-auto p-0 header-3-1 position-relative"
        style={{
          fontFamily: '"Poppins", sans-serif',
          backgroundColor: "white",
        }}
      >
        <HeaderUbaya />
        <Navbar />
        <Routes>
          <Route path="*" element={<NotFound />} />
          <Route path="/" element={<Content />} />
          <Route path="/data/:tanaman" element={<Datacontent />} />
          <Route path="/senyawa/:senyawa" element={<DataSenyawa />} />
          <Route path="/detail/:tanaman/:senyawa" element={<DetailData />} />
          <Route
            path="/detail/senyawa/:tanaman/:senyawa"
            element={<DetailSenyawa />}
          />
          <Route path="/browse/herbal" element={<Browse />} />
          <Route path="/browse/sintesis" element={<BrowseSintesis />} />
          <Route path="/news" element={<Berita />} />
          <Route path="/about-us" element={<AboutUs />} />
          <Route path="/galery" element={<Gallery />} />
          <Route path="/galery/all" element={<AllGaleri />} />
          <Route path="/contribute" element={<Contribute />} />
          <Route path="/spektra" element={<Spektra />} />
          <Route path="/detail/spektra/:senyawa" element={<Detailspektra />} />
          <Route path="/terbaru" element={<TerbaruTanaman />} />
          <Route path="/products" element={<ProductPage />} />
          <Route path="/detail/video/:judul" element={<DetailVideo />} />
        </Routes>
        <FooterUbaya />
      </div>
    </>
  );
}

export default App;
