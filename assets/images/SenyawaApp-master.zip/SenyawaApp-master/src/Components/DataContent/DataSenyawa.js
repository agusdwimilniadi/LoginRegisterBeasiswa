import React, { useEffect, useState } from "react";
import DataTable from "react-data-table-component";
import dataJSON from "../../Data/DataSenyawaSintesis";
import { useParams } from "react-router-dom";

const DataSenyawa = () => {
  const columns = [
    {
      name: "No",
      cell: (_, index) => index + 1,
      grow: 0,
    },

    {
      name: "Nama Senyawa",
      selector: (row) => row.senyawa,
      sortable: true,
    },
    {
      name: "Action",
      selector: (row) => (
        <>
          <a
            className="btn btn-primary"
            href={`/detail/senyawa/${row["Nama Populer"]}/${row.senyawa}`}
          >
            Detail
          </a>
        </>
      ),
      sortable: true,
    },
  ];
  const customStyles = {
    rows: {
      style: {
        minHeight: "72px", // override the row height
      },
    },
    headCells: {
      style: {
        paddingLeft: "8px", // override the cell padding for head cells
        paddingRight: "8px",
        fontWeight: "bold",
        borderBottom: "3px solid black",
      },
    },
    cells: {
      style: {
        paddingLeft: "8px", // override the cell padding for data cells
        paddingRight: "8px",
      },
    },
  };
  const [dataFix, setDataFix] = useState([]);
  const dataParams = useParams();

  console.log("Data param ", dataParams);
  function dataFilter(dataMentah) {
    const filtered = dataMentah.filter((obj) =>
      obj.senyawa?.toLowerCase().includes(`${dataParams.senyawa}`.toLowerCase())
    );
    setDataFix(filtered);
  }

  useEffect(() => {
    // dataFilter(dataJSON);
    // console.log("Data resmi ", dataResmiPopuler);
    dataFilter(dataJSON);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  });
  return (
    <div style={{ height: "auto" }}>
      <div className="container mt-5" style={{ height: "auto" }}>
        <DataTable
          columns={columns}
          data={dataFix}
          pagination
          customStyles={customStyles}
          noDataComponent="Data tidak ada"
          pageSiz
        />
        ;
      </div>
    </div>
  );
};

export default DataSenyawa;
