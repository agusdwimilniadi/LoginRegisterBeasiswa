import React from "react";
import Header from "../../images/Header.svg";
import Ubaya2 from "../../images/sociaa.png";

export default function HeaderUbaya() {
  return (
    <>
      <div style={{ height: "auto", backgroundColor: "white" }}>
        <div className="container">
          <div className="row pt-2 mb-2">
            <div className="col-6 ">
              <img src={Ubaya2} alt="" className="img-fluid " width="70%" />
            </div>
            <div className="col-6 text-end my-auto ">
              <img src={Header} alt="" className="img-fluid" width="50%" />
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
