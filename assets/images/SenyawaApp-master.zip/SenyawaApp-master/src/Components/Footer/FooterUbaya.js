import React, { useEffect, useState } from "react";
import axios from "axios";

export default function FooterUbaya() {
  const [counter, setCounter] = useState("");

  const counterWebsite = async () => {
    let result = await axios
      .get("https://api.countapi.xyz/update/senyawa-ubaya/ubaya123?amount=0.5")
      .catch((e) => {
        console.log(e);
      });
    setCounter(result.data.value);
  };
  useEffect(() => {
    if (counter === "") {
      counterWebsite();
    } else {
      void 0;
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  return (
    <>
      <div className="row mt-5 m-0 p-0">
        <div className="col-md-5 "></div>
        <div className="col-md-2 m-0 p-0">
          <div className="box-counter text-center p-2 position-relative">
            <img
              src="https://www.svgrepo.com/show/304828/stats-increase.svg"
              alt=""
              height="10%"
              width="10%"
              className="img-fluid"
            />
            <h3 className="fw-bold m-0">{counter}</h3>
            <p className="" style={{ fontSize: "12px" }}>
              Orang telah mengunjungi website anda
            </p>
          </div>
        </div>
        <div className="col-md-4 m-0 p-0"></div>
      </div>
      <div
        className="py-2 pt-3 mt-5"
        style={{ backgroundColor: "#353381", borderRadius: "20px" }}
      >
        <div className="container ">
          <div className="row">
            <div
              className="col-12 text-center fw-bold"
              style={{ color: "#DBDBDB" }}
            >
              <p>© Fakultas Farmasi Universitas Surabaya</p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
