import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import gambar1 from "../../images/flower/1-removebg-preview.png";
import gambar2 from "../../images/flower/2-removebg-preview.png";
import gambar3 from "../../images/flower/3-removebg-preview.png";
import gambar4 from "../../images/flower/4-removebg-preview.png";

export default function Content() {
  const [dataSearch, setDataSearch] = useState({
    tanaman: "",
    senyawa: "",
  });
  const navigate = useNavigate();

  const onchange = (e) => {
    const name = e.target.name;
    const value = e.target.value;
    setDataSearch({
      ...dataSearch,
      [name]: value,
    });
    console.log("Ini data search ", dataSearch);
  };
  const resetData = () => {
    setDataSearch({
      tanaman: "",
      senyawa: "",
    });
  };

  return (
    <div>
      <div>
        <div className="container" style={{ height: "auto" }}>
          {/* Left Column */}
          <div className="row">
            <div className="col-md-4"></div>
            <div
              className="col-md-4 text-center my-5 py-2 px-5"
              style={{ backgroundColor: "#353381", borderRadius: "20px" }}
            >
              <h1 className="text-dark fs-2 text-white">Pencarian SAE</h1>
            </div>
            <div className="col-md-4"></div>

            <div className="col-md-6 mt-4 text-dark">
              <div
                className="p-3 rounded"
                style={{ backgroundColor: "#D9D9D9" }}
              >
                <div className="row">
                  <div
                    className="col-4 offset-4 text-center py-2 text-white"
                    style={{ borderRadius: "20px", backgroundColor: "#353381" }}
                  >
                    Senyawa Herbal
                  </div>
                </div>
                <div className="mb-3">
                  <label
                    htmlFor="exampleFormControlInput1"
                    className="form-label"
                  >
                    Pencarian
                  </label>

                  <input
                    type="text"
                    name="tanaman"
                    className="form-control"
                    id="exampleFormControlInput1"
                    placeholder="Nama Latin, Nama Indonesia, Nama senyawa"
                    onChange={onchange}
                    value={dataSearch.tanaman}
                    required
                  />
                </div>

                <div className="d-grid gap-2 mt-4">
                  <button
                    disabled={dataSearch.tanaman === "" ? true : false}
                    class="btn  text-white"
                    type="submit"
                    style={{ backgroundColor: "#353381" }}
                    onClick={() => {
                      navigate(`/data/${dataSearch.tanaman}`);
                    }}
                  >
                    Cari
                  </button>

                  <button class="btn btn-danger" onClick={resetData}>
                    Hapus
                  </button>
                </div>
              </div>
              <div className="text-center mt-4">
                <a
                  href="https://firebasestorage.googleapis.com/v0/b/senyawa-49872.appspot.com/o/FHI%20edisi%20II%202017.pdf?alt=media&token=c308a04a-9008-475b-a724-a82203f7d527"
                  className="text-dark fw-bold"
                  target="_blank"
                  style={{ textDecoration: "none" }}
                  rel="noreferrer"
                >
                  <u>FARMAKOPE HERBAL INDONESIA EDISI II </u>
                </a>
              </div>
            </div>
            <div className="col-md-6 mt-4  text-dark">
              <div
                className="p-3 rounded"
                style={{ backgroundColor: "#D9D9D9" }}
              >
                <div className="row">
                  <div
                    className="col-4 offset-4 text-center py-2 text-white"
                    style={{ borderRadius: "20px", backgroundColor: "#353381" }}
                  >
                    Senyawa Sintesis
                  </div>
                </div>
                <div className="mb-3">
                  <label
                    htmlFor="exampleFormControlInput1"
                    className="form-label"
                  >
                    Pencarian
                  </label>
                  <input
                    name="senyawa"
                    type="text"
                    className="form-control"
                    id="exampleFormControlInput1"
                    placeholder="Nama Senyawa"
                    onChange={onchange}
                    value={dataSearch.senyawa}
                    required
                  />
                </div>
                <div className="d-grid gap-2 mt-4">
                  <button
                    disabled={dataSearch.senyawa === "" ? true : false}
                    class="btn text-white"
                    type="submit"
                    style={{ backgroundColor: "#353381" }}
                    onClick={() => {
                      navigate(`/senyawa/${dataSearch.senyawa}`);
                    }}
                  >
                    Cari
                  </button>

                  <button class="btn btn-danger" onClick={resetData}>
                    Hapus
                  </button>
                </div>
              </div>
              <div className="text-center mt-4">
                <a
                  href="https://firebasestorage.googleapis.com/v0/b/senyawa-49872.appspot.com/o/Farmakope%20Indonesia%20Ed%20VI%202020.pdf?alt=media&token=637f0452-1e70-433f-a935-073bb3d864cf"
                  className="text-dark fw-bold"
                  target="_blank"
                  style={{ textDecoration: "none" }}
                  rel="noreferrer"
                >
                  <u>FARMAKOPE INDONESIA VI JILID I</u>
                </a>
              </div>
            </div>

            <div className="col-md-12 mt-5"></div>
            <div className="row d-flex align-items-center">
              <div className="col-3">
                <img src={gambar1} alt="" className="img-fluid" />
              </div>
              <div className="col-3">
                <img src={gambar2} alt="" className="img-fluid" />
              </div>
              <div className="col-3">
                <img src={gambar3} alt="" className="img-fluid" />
              </div>
              <div className="col-3">
                <img src={gambar4} alt="" className="img-fluid" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
