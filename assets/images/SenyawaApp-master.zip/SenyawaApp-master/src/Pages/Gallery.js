import React, { useEffect, useState } from "react";
import { Carousel } from "react-bootstrap";
import dataimage from "../Data/DataGalerii";
import { Link } from "react-router-dom";

const Gallery = (props) => {
  const [dataCarusel, setDataCarusel] = useState([]);
  const dataGambar = dataimage.images;
  function setCarusell() {
    const top3 = dataimage.carousel;
    setDataCarusel(top3);
  }
  useEffect(() => {
    setCarusell();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  return (
    <>
      {/* eslint-disable */}
      <div className="container my-5">
        <h1 className="text-center">Galeri</h1>

        <Carousel className="my-5">
          {dataCarusel.map((review) => (
            <Carousel.Item key={review.id}>
              <img className="testimonialImages" src={review.url} />
            </Carousel.Item>
          ))}
        </Carousel>

        <div className="row">
          {dataGambar.slice(-9).map((item) => {
            return (
              <div className="col-lg-4 col-md-12 mb-4 mb-lg-0">
                <img
                  src={item.url}
                  className="w-100 shadow-1-strong rounded mb-4"
                  alt="Boat on Calm Water"
                />
              </div>
            );
          })}
          <div className="col-md-12 text-end">
            <Link to="/galery/all" className="btn btn-transparent ">
              <u>Lainnya</u>
            </Link>
          </div>
        </div>
      </div>
    </>
  );
};

export default Gallery;
