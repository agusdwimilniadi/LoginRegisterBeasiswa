import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import dataProduct from "../Data/DataProduct";
import PlayerManual from "../Pages/PlayerManual";
export default function DetailVideo() {
  const parameter = useParams();
  const [dataFiltered, setdataFiltered] = useState([]);
  function dataFilter(dataMentah) {
    const filtered = dataMentah.filter((obj) =>
      obj.judulVideo?.toLowerCase().includes(`${parameter.judul}`.toLowerCase())
    );
    setdataFiltered(filtered);
  }
  useEffect(() => {
    dataFilter(dataProduct);
    console.log("Data resmi ", dataFiltered[0]?.linkVideo);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dataProduct]);
  return (
    <div>
      <div className="container">
        <div className="row">
          <div className="col-md-12 mt-5">
            <PlayerManual urlPlayer={dataFiltered[0]?.linkVideo} />
            {/* <ReactPlayer url={dataFiltered[0]?.linkVideo} /> */}
            <div className="desc-data">
              <h1>{dataFiltered[0]?.judulVideo}</h1>
              <p>{dataFiltered[0]?.desc}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
