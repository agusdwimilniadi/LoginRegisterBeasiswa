import React from "react";
import DataTable from "react-data-table-component";
import dataJSON from "../Data/DataSenyawaHerbal";

export default function Browse() {
  const columns = [
    {
      name: "No",
      cell: (_, index) => index + 1,
      grow: 0,
    },
    {
      name: "Nama Resmi",
      selector: (row) => row["Nama Resmi"],
      sortable: true,
    },
    {
      name: "Nama Populer",
      selector: (row) => row["Nama Populer"],
      sortable: true,
    },
    {
      name: "Nama Senyawa",
      selector: (row) => row.senyawa,
      sortable: true,
    },
    {
      name: "Action",
      selector: (row) => (
        <>
          <a
            className="btn btn-primary"
            href={`/detail/${row["Nama Populer"]}/${row.senyawa}`}
          >
            Detail
          </a>
        </>
      ),
      sortable: true,
    },
  ];
  const [filterText, setFilterText] = React.useState("");
  const [resetPaginationToggle, setResetPaginationToggle] =
    React.useState(false);
  const filteredItems = dataJSON.filter(
    (item) =>
      (item["Nama Populer"] &&
        item["Nama Populer"]
          .toLowerCase()
          .includes(filterText.toLowerCase())) ||
      (item["Nama Resmi"] &&
        item["Nama Resmi"].toLowerCase().includes(filterText.toLowerCase())) ||
      (item.senyawa &&
        item.senyawa.toLowerCase().includes(filterText.toLowerCase()))
  );

  const subHeaderComponentMemo = React.useMemo(() => {
    const handleClear = () => {
      if (filterText) {
        setResetPaginationToggle(!resetPaginationToggle);
        setFilterText("");
      }
    };

    return (
      <>
        <div className="mt-5 d-flex input-group">
          <input
            onChange={(e) => setFilterText(e.target.value)}
            value={filterText}
            className="form-control"
            size="100%"
            placeholder="Cari..."
          />
          <button className="btn btn-primary ms-4" onClick={handleClear}>
            Clear
          </button>
        </div>
      </>
    );
  }, [filterText, resetPaginationToggle]);
  return (
    <div>
      <div className="container pt-5">
        <div className="row">
          <div
            className="col-md-4 offset-md-4"
            style={{ borderRadius: "20px", backgroundColor: "#353381" }}
          >
            <h1 className="text-center py-2 text-white">Index Semua Tanaman</h1>
          </div>
        </div>

        <DataTable
          columns={columns}
          data={filteredItems}
          pagination
          noDataComponent="Data tidak ada"
          paginationResetDefaultPage={resetPaginationToggle} // optionally, a hook to reset pagination to page 1
          subHeader
          subHeaderComponent={subHeaderComponentMemo}
          persistTableHead
        />
      </div>
    </div>
  );
}
