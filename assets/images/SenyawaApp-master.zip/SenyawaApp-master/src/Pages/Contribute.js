import React from "react";
import dataJabatan from "../Data/DataContribute";

export default function Contribute() {
  let dataJabatanK = dataJabatan;
  return (
    <>
      <div className="container">
        <h1 className="text-center my-5">Contribute</h1>
        {dataJabatanK.data.map((item) => {
          return (
            <ul>
              <h4 className="fw-bold">
                {item.role} : <span className="fw-normal">{item.nama}</span>{" "}
              </h4>
              {item.dataAnggota.length === 0 ? (
                ""
              ) : (
                <h4 className="fw-bold">Anggota : </h4>
              )}

              {item.dataAnggota.map((item2) => {
                return (
                  <>
                    {item2.nama === "" && item2.email === "" ? (
                      ""
                    ) : (
                      <li style={{ marginLeft: "7rem" }}>
                        {item2.nama === "" ? (
                          ""
                        ) : (
                          <h4 className="fw-normal">Nama : {item2.nama}</h4>
                        )}
                        {item2.email === "" ? (
                          ""
                        ) : (
                          <h4 className="fw-normal">Email : {item2.email}</h4>
                        )}
                      </li>
                    )}
                  </>
                );
              })}
            </ul>
          );
        })}
      </div>
    </>
  );
}
