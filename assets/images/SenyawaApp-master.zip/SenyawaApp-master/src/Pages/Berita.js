import React from "react";
import dataBerita from "../Data/DataBerita";

export default function Berita() {
  return (
    <>
      {/* eslint-disable */}
      <div className="container">
        <div className="row pb-5">
          <h1 className="text-center color-green  mb-3 mt-3">Berita Terbaru</h1>
          <hr className="text-dark" />
          {dataBerita.map((item) => {
            return (
              <>
                <div className="col-md-4 text-sm-center text-md-start my-2">
                  <a href={`${item.url}`} target="_blank">
                    <img
                      src={`${item.image}`}
                      alt=""
                      className="img-fluid rounded"
                      width="80%"
                    />
                  </a>
                </div>
                <div className="col-md-8 text-dark  d-flex align-items-center ">
                  <div>
                    <a
                      href={`${item.url}`}
                      target="_blank"
                      className="text-dark"
                      style={{ textDecoration: "none" }}
                    >
                      <h4 className="fw-bold text-sm-center text-md-start">
                        {item.judul}
                      </h4>
                    </a>
                    <p
                      className="text-sm-center text-md-start"
                      style={{ fontSize: "12px" }}
                    >
                      {item.desc}
                    </p>
                  </div>
                </div>
              </>
            );
          })}
        </div>
      </div>
    </>
  );
}
