import React from "react";
import DataTable from "react-data-table-component";
import dataVideo from "../Data/DataVideo";

export default function Spektra() {
  const columns = [
    {
      name: "No",
      cell: (_, index) => index + 1,
      grow: 0,
    },
    {
      name: "Nama Senyawa",
      selector: (row) => row.senyawa,
      sortable: true,
    },
    {
      name: "Action",
      selector: (row) => (
        <>
          <a
            className="btn btn-primary"
            href={`/detail/spektra/${row.senyawa}`}
          >
            Detail
          </a>
        </>
      ),
      sortable: true,
    },
  ];
  const [filterText, setFilterText] = React.useState("");
  const [resetPaginationToggle, setResetPaginationToggle] =
    React.useState(false);
  const filteredItems = dataVideo.filter(
    (item) =>
      item.senyawa &&
      item.senyawa.toLowerCase().includes(filterText.toLowerCase())
  );

  const subHeaderComponentMemo = React.useMemo(() => {
    const handleClear = () => {
      if (filterText) {
        setResetPaginationToggle(!resetPaginationToggle);
        setFilterText("");
      }
    };

    return (
      <>
        <div className="mt-5 d-flex input-group">
          <input
            onChange={(e) => setFilterText(e.target.value)}
            value={filterText}
            className="form-control"
            size="100%"
            placeholder="Cari..."
          />
          <button className="btn btn-primary ms-4" onClick={handleClear}>
            Clear
          </button>
        </div>
      </>
    );
  }, [filterText, resetPaginationToggle]);
  return (
    <>
      <div className="container">
        <div className="col-md-12">
          <DataTable
            columns={columns}
            data={filteredItems}
            pagination
            noDataComponent="Data tidak ada"
            paginationResetDefaultPage={resetPaginationToggle} // optionally, a hook to reset pagination to page 1
            subHeader
            subHeaderComponent={subHeaderComponentMemo}
            persistTableHead
          />
        </div>
      </div>
    </>
  );
}
