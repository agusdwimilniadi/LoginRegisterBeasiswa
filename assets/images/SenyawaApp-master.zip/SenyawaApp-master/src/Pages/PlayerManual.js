import React from "react";

export default function PlayerManual(props) {
  function getId(url) {
    const regExp =
      /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/;
    let match = url?.match(regExp);

    return match && match[2].length === 11 ? match[2] : null;
  }

  const videoId = getId(props?.urlPlayer);
  const iframeMarkup = `https://www.youtube.com/embed/${videoId}`;

  return (
    <div
      class="ratio ratio-16x9 m-auto margin-woy"
      style={{ marginLeft: "25% !important" }}
    >
      <iframe
        src={iframeMarkup}
        title="YouTube video"
        allowfullscreen
        height="100px"
      ></iframe>
    </div>
  );
}
