import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import dataJSON from "../Data/DataSenyawaHerbal";
export default function DetailData() {
  const parameter = useParams();
  const [dataFiltered, setdataFiltered] = useState([]);
  function dataFilter(dataMentah) {
    const filtered = dataMentah.filter(
      (obj) =>
        obj["Nama Populer"]
          ?.toLowerCase()
          .includes(`${parameter.tanaman}`.toLowerCase()) &&
        obj.senyawa
          ?.toLowerCase()
          .includes(`${parameter.senyawa}`.toLowerCase())
    );
    setdataFiltered(filtered);
  }
  useEffect(() => {
    dataFilter(dataJSON);
    // console.log("Data resmi ", dataResmiPopuler);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  });
  return (
    <>
      <div className="container text-dark mt-5">
        <div className="row">
          {dataFiltered?.map((item) => {
            return (
              <>
                <h4 className="text-center">Detail Data</h4>

                <hr />
                <div className="col-md-4 offset-md-4">
                  <img
                    src={`${item.gambar}`}
                    alt=""
                    className="img-fluid rounded my-3"
                  />
                </div>
                <div className="col-md-6 ">
                  <div className="box-tanaman m-auto text-white">
                    Nama Latin Tanaman
                  </div>
                  <div className="text-center my-2">{item["Nama Resmi"]}</div>
                </div>
                <div className="col-md-6 ">
                  <div className="box-tanaman m-auto text-white">
                    Nama Tanaman Indonesia
                  </div>
                  <div className="text-center my-2">{item["Nama Populer"]}</div>
                </div>
                <div className="col-md-6 ">
                  <div className="box-tanaman m-auto text-white">
                    Nama Simplisia
                  </div>
                  <div className="text-center my-2">
                    {item["Nama Simplisia"]}
                  </div>
                </div>
                <div className="col-md-6 ">
                  <div className="box-tanaman m-auto text-white">
                    Nama IUPAC Senyawa
                  </div>
                  <div className="text-center my-2">{item.senyawa}</div>
                </div>
                <div className="col-md-6 offset-md-3">
                  <div className="box-tanaman m-auto text-white">Smiles</div>
                  <div className="text-center my-2">{item.smiles}</div>
                </div>
                <div className="col-md-12 text-center"></div>

                <div className="col-md-4">
                  <div className="text-center my-4"></div>
                  <table className="table table-primary">
                    <thead>
                      <tr>
                        <th colSpan={1} className="text-center table-danger">
                          Menurut Egan
                        </th>
                      </tr>
                      <tr>
                        <th colSpan={1} className="text-center">
                          TPSA
                        </th>
                      </tr>
                      <tr>
                        <th colSpan={1} className="text-center">
                          ≤ 131.6 Å
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <th className="text-center table-light">{item.TPSA}</th>
                      </tr>
                    </tbody>
                  </table>
                </div>
                <div className="col-md-4">
                  <div className="text-center my-4"></div>
                  <table className="table table-primary">
                    <thead>
                      <tr>
                        <th colSpan={2} className="text-center table-danger">
                          Menurut Veber
                        </th>
                      </tr>
                      <tr>
                        <th colSpan={1} className="text-center">
                          Rotatable Bonds
                        </th>
                        <th colSpan={1} className="text-center">
                          TPSA
                        </th>
                      </tr>
                      <tr>
                        <th colSpan={1} className="text-center">
                          ≤10
                        </th>
                        <th colSpan={1} className="text-center">
                          ≤140 Å
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <th className="text-center table-light">
                          {item["6Rotatable Bonds"]}
                        </th>
                        <th className="text-center table-light">
                          {item["6TPSA"]}
                        </th>
                      </tr>
                    </tbody>
                  </table>
                </div>
                <div className="col-md-4">
                  <div className="text-center my-4"></div>
                  <table className="table table-primary">
                    <thead>
                      <tr>
                        <th colSpan={4} className="text-center table-danger">
                          Menurut Ghose
                        </th>
                      </tr>
                      <tr>
                        <th colSpan={1} className="text-center">
                          ALogP
                        </th>
                        <th colSpan={1} className="text-center">
                          MR
                        </th>
                        <th colSpan={1} className="text-center">
                          MW
                        </th>
                        <th colSpan={1} className="text-center">
                          ∑ Atoms
                        </th>
                      </tr>
                      <tr>
                        <th colSpan={1} className="text-center">
                          ≤ 131.6 Å
                        </th>
                        <th colSpan={1} className="text-center">
                          -0,4 ≤ x ≤ 5,6
                        </th>
                        <th colSpan={1} className="text-center">
                          40 ≤ x ≤ 130
                        </th>
                        <th colSpan={1} className="text-center">
                          160 ≤ x ≤ 480
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <th className="text-center table-light">
                          {item["1ALogP"]}
                        </th>
                        <th className="text-center table-light">
                          {item["1MR"]}
                        </th>
                        <th className="text-center table-light">
                          {item["1MW"]}
                        </th>
                        <th className="text-center table-light">
                          {item["1∑ Atoms"]}
                        </th>
                      </tr>
                    </tbody>
                  </table>
                </div>
                <div className="col-md-12">
                  <div className="text-center my-4"></div>
                  <table className="table table-primary">
                    <thead>
                      <tr>
                        <th colSpan={5} className="text-center table-danger">
                          Menurut Lipinski
                        </th>
                      </tr>
                      <tr>
                        <th colSpan={1} className="text-center">
                          MW
                        </th>
                        <th colSpan={1} className="text-center">
                          CLogP
                        </th>
                        <th colSpan={1} className="text-center">
                          MLogP
                        </th>
                        <th colSpan={1} className="text-center">
                          HBD
                        </th>
                        <th colSpan={1} className="text-center">
                          HBA
                        </th>
                      </tr>
                      <tr>
                        <th colSpan={1} className="text-center">
                          ≤500
                        </th>
                        <th colSpan={1} className="text-center">
                          ≤5
                        </th>
                        <th colSpan={1} className="text-center">
                          ≤4,1
                        </th>
                        <th colSpan={1} className="text-center">
                          ≤5
                        </th>
                        <th colSpan={1} className="text-center">
                          ≤10
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <th className="text-center table-light">
                          {item["2MW"]}
                        </th>
                        <th className="text-center table-light">
                          {item["2CLogP"]}
                        </th>
                        <th className="text-center table-light">
                          {item["2MLogP"]}
                        </th>
                        <th className="text-center table-light">
                          {item["2HBD"]}
                        </th>
                        <th className="text-center table-light">
                          {item["2HBA"]}
                        </th>
                      </tr>
                    </tbody>
                  </table>
                </div>
                <div className="col-md-12">
                  <div className="text-center my-4"></div>
                  <table className="table table-primary">
                    <thead>
                      <tr>
                        <th colSpan={9} className="text-center table-danger">
                          Menurut Muegge
                        </th>
                      </tr>
                      <tr>
                        <th colSpan={1} className="text-center">
                          MW
                        </th>
                        <th colSpan={1} className="text-center">
                          HBD{" "}
                        </th>
                        <th colSpan={1} className="text-center">
                          HBA
                        </th>
                        <th colSpan={1} className="text-center">
                          Rotatable Bonds
                        </th>
                        <th colSpan={1} className="text-center">
                          Ring Number
                        </th>
                        <th colSpan={1} className="text-center">
                          TPSA
                        </th>
                        <th colSpan={1} className="text-center">
                          XLogP
                        </th>
                        <th colSpan={1} className="text-center">
                          C Numbers
                        </th>
                        <th colSpan={1} className="text-center">
                          Heteroatom Numbers
                        </th>
                      </tr>
                      <tr>
                        <th colSpan={1} className="text-center">
                          200 ≤ x ≤ 600
                        </th>
                        <th colSpan={1} className="text-center">
                          ≤5
                        </th>
                        <th colSpan={1} className="text-center">
                          ≤10
                        </th>
                        <th colSpan={1} className="text-center">
                          ≤15
                        </th>
                        <th colSpan={1} className="text-center">
                          ≤7
                        </th>
                        <th colSpan={1} className="text-center">
                          ≤ 150 Å
                        </th>
                        <th colSpan={1} className="text-center">
                          -2 ≤ x ≤ 5
                        </th>
                        <th colSpan={1} className="text-center">
                          {">"}4
                        </th>
                        <th colSpan={1} className="text-center">
                          {">"}1
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <th className="text-center table-light">
                          {item["3MW"]}
                        </th>
                        <th className="text-center table-light">
                          {item["3HBD"]}
                        </th>
                        <th className="text-center table-light">
                          {item["3HBA"]}
                        </th>
                        <th className="text-center table-light">
                          {item["3Rotatable Bonds "]}
                        </th>
                        <th className="text-center table-light">
                          {item["3Ring Number"]}
                        </th>
                        <th className="text-center table-light">
                          {item["3TPSA"]}
                        </th>
                        <th className="text-center table-light">
                          {item["3XLogP"]}
                        </th>
                        <th className="text-center table-light">
                          {item["3C Numbers"]}
                        </th>
                        <th className="text-center table-light">
                          {item["3Heteroatom Numbers"]}
                        </th>
                      </tr>
                    </tbody>
                  </table>
                </div>
                <div className="col-md-5">
                  <div className="text-center my-4"></div>
                  <table className="table table-primary">
                    <thead>
                      <tr>
                        <th colSpan={4} className="text-center table-danger">
                          Menurut Oprea
                        </th>
                      </tr>
                      <tr>
                        <th colSpan={1} className="text-center">
                          HBD
                        </th>
                        <th colSpan={1} className="text-center">
                          HBA
                        </th>
                        <th colSpan={1} className="text-center">
                          Rotatable Bonds
                        </th>
                        <th colSpan={1} className="text-center">
                          Ring Number
                        </th>
                      </tr>
                      <tr>
                        <th colSpan={1} className="text-center">
                          ≤2
                        </th>
                        <th colSpan={1} className="text-center">
                          2 ≤ x ≤ 9
                        </th>
                        <th colSpan={1} className="text-center">
                          2 ≤ x ≤ 8
                        </th>
                        <th colSpan={1} className="text-center">
                          1 ≤ x ≤ 4
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <th className="text-center table-light">
                          {item["4HBD"]}
                        </th>
                        <th className="text-center table-light">
                          {item["4HBA"]}
                        </th>
                        <th className="text-center table-light">
                          {item["4Rotatable Bonds"]}
                        </th>
                        <th className="text-center table-light">
                          {item["4Ring Number"]}
                        </th>
                      </tr>
                    </tbody>
                  </table>
                </div>
                <div className="col-md-7">
                  <div className="text-center my-4"></div>
                  <table className="table table-primary">
                    <thead>
                      <tr>
                        <th colSpan={6} className="text-center table-danger">
                          Menurut REOS
                        </th>
                      </tr>
                      <tr>
                        <th colSpan={1} className="text-center">
                          MW
                        </th>
                        <th colSpan={1} className="text-center">
                          CLogP
                        </th>
                        <th colSpan={1} className="text-center">
                          HBD
                        </th>
                        <th colSpan={1} className="text-center">
                          HBA
                        </th>
                        <th colSpan={1} className="text-center">
                          Rotatable Bonds
                        </th>
                        <th colSpan={1} className="text-center">
                          Formal Charge
                        </th>
                      </tr>
                      <tr>
                        <th colSpan={1} className="text-center">
                          200 ≤ x ≤ 500
                        </th>
                        <th colSpan={1} className="text-center">
                          -5 ≤ x ≤ 5
                        </th>
                        <th colSpan={1} className="text-center">
                          ≤ 5
                        </th>
                        <th colSpan={1} className="text-center">
                          ≤ 10
                        </th>
                        <th colSpan={1} className="text-center">
                          ≤ 8
                        </th>
                        <th colSpan={1} className="text-center ">
                          -2 ≤ x ≤ 2
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <th className="text-center table-light">
                          {item["5MW"]}
                        </th>
                        <th className="text-center table-light">
                          {item["5CLogP"]}
                        </th>
                        <th className="text-center table-light">
                          {item["5HBD"]}
                        </th>
                        <th className="text-center table-light">
                          {item["5HBA"]}
                        </th>
                        <th className="text-center table-light">
                          {item["5Rotatable Bonds"]}
                        </th>
                        <th className="text-center table-light">
                          {item["5Formal Charge"]}
                        </th>
                      </tr>
                    </tbody>
                  </table>
                </div>

                <div className="col-md-12">
                  <div className="text-center my-4"></div>
                  <table className="table table-primary">
                    <thead>
                      <tr>
                        <th rowSpan={1} className="text-center table-danger">
                          REFRENSI PUBCHEM
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <th className="text-center table-light">
                          {item["REFRENSI PUBCHEM"] === "-" ? (
                            "Tidak tersedia"
                          ) : (
                            <a
                              target="_blank"
                              href={`${item["REFRENSI PUBCHEM"]}`}
                              rel="noreferrer"
                            >
                              Link
                            </a>
                          )}
                        </th>
                      </tr>
                      <tr>
                        <th rowSpan={1} className="text-center table-danger">
                          REFRENSI CHEMSPIDER
                        </th>
                      </tr>
                      <tr>
                        <th className="text-center table-light">
                          {item["REFRENSI CHEMSPIDER"] === "-" ? (
                            "Tidak tersedia"
                          ) : (
                            <a
                              target="_blank"
                              href={`${item["REFRENSI CHEMSPIDER"]}`}
                              rel="noreferrer"
                            >
                              Link
                            </a>
                          )}
                        </th>
                      </tr>
                      <tr>
                        <th
                          rowSpan={1}
                          className="text-center table-danger text-uppercase"
                        >
                          reverensi swissadme
                        </th>
                      </tr>
                      <tr>
                        <th className="text-center table-light">
                          <a
                            target="_blank"
                            href={`http://www.swissadme.ch/`}
                            rel="noreferrer"
                          >
                            Link
                          </a>
                        </th>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </>
            );
          })}
        </div>
      </div>
    </>
  );
}
