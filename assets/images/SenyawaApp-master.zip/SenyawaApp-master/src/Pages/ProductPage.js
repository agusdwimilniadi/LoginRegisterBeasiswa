import React from "react";
import dataProduct from "../Data/DataProduct";

export default function ProductPage() {
  return (
    <>
      {/* eslint-disable */}
      <div className="container">
        <div className="row pb-5">
          <h1 className="text-center color-green  mb-3 mt-3">Product</h1>
          <hr className="text-dark" />
          {dataProduct.map((item) => {
            const grabLink = require("youtube-thumbnail-grabber");
            const linkImage = grabLink(`${item.linkVideo}`, "sd");
            return (
              <>
                <div className="col-md-4 text-sm-center text-md-start my-2">
                  <a href={`/detail/video/${item.judulVideo}`} target="_blank">
                    <img
                      src={`${linkImage}`}
                      alt=""
                      className="img-fluid rounded"
                      width="80%"
                    />
                  </a>
                </div>
                <div className="col-md-8 text-dark  d-flex align-items-center ">
                  <div>
                    <a
                      href={`/detail/video/${item.judulVideo}`}
                      className="text-dark"
                      style={{ textDecoration: "none" }}
                    >
                      <h4 className="fw-bold text-sm-center text-md-start">
                        {item.judulVideo}
                      </h4>
                    </a>
                    <p
                      className="text-sm-center text-md-start"
                      style={{ fontSize: "12px" }}
                    >
                      {item.desc}
                    </p>
                  </div>
                </div>
              </>
            );
          })}
        </div>
      </div>
    </>
  );
}
