import React, { useEffect } from "react";
import dataimage from "../Data/DataGalerii";

export default function AllGaleri() {
  let dataGambar = dataimage.images;
  useEffect(() => {
    window.scrollTo(0, 0);
  });
  return (
    <>
      <div className="container">
        <div className="row">
          <div className="col-md-12">
            <h1 className="my-5 text-center">Semua Galerry</h1>
          </div>
          {dataGambar
            .slice(0)
            .reverse()
            .map((item) => {
              return (
                <div className="col-lg-4 col-md-12 mb-4 mb-lg-0">
                  <img
                    src={item.url}
                    className="w-100 shadow-1-strong rounded mb-4"
                    alt="Boat on Calm Water"
                  />
                </div>
              );
            })}
        </div>
      </div>
    </>
  );
}
