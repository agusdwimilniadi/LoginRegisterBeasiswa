import React from "react";
import dataJSON from "../Data/DataSenyawaHerbal";

export default function TerbaruSenyawa() {
  let dataLoop2 = dataJSON;
  return (
    <div>
      <div>
        <div className="container pt-5">
          <div className="row">
            <div
              className="col-md-4 offset-md-4"
              style={{ borderRadius: "20px", backgroundColor: "#353381" }}
            >
              <h1 className="text-center py-2 px-2 text-white">
                Senyawa Terbaru
              </h1>
            </div>
            <div className="col-md-12">
              <table className="table table-striped mt-5">
                <thead>
                  <tr>
                    <th scope="col">No</th>
                    <th scope="col">Nama Resmi</th>
                    <th scope="col">Nama Populer</th>
                    <th scope="col">Nama Senyawa</th>
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {dataLoop2
                    .slice(0)
                    .reverse()
                    .slice(0, 10)
                    .map((item, index) => {
                      return (
                        <tr>
                          <th scope="row">{index + 1}</th>
                          <td>{item["Nama Resmi"]}</td>
                          <td>{item["Nama Populer"]}</td>
                          <td>{item["Nama Simplisia"]}</td>
                          <td>
                            <a
                              className="btn btn-primary"
                              href={`/detail/senyawa/${item["Nama Populer"]}/${item.senyawa}`}
                            >
                              Detail
                            </a>
                          </td>
                        </tr>
                      );
                    })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
