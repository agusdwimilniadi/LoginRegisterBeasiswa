import React, { useEffect, useState } from "react";
import DataTable from "react-data-table-component";
// import ReactPlayer from "react-player";
import { useParams } from "react-router-dom";
import dataVideo from "../Data/DataVideo";
import imageLoading from "../images/Spinner-1s-200px (1).gif";

const Detailspektra = () => {
  const [imageData, setImageData] = useState("");
  const [loading, setLoading] = useState(false);

  const parameter = useParams();
  const [dataFiltered, setdataFiltered] = useState([]);
  const [dataRemap, setDataRemap] = useState([]);
  function dataFilter(dataMentah) {
    const filtered = dataMentah.filter((obj) =>
      obj.senyawa?.toLowerCase().includes(`${parameter.senyawa}`.toLowerCase())
    );
    setdataFiltered(filtered);
    const remap = dataFiltered
      ?.map((something) => something?.videoData)
      ?.reduce((curr, acc) => curr.concat(acc), []);
    setDataRemap(remap);
  }
  function changeImage(imageData) {
    setLoading(true);
    setImageData(imageData);
    setTimeout(function () {
      setLoading(false);
    }, 1000);
  }

  const columns = [
    {
      name: "v (cm-1)	",
      selector: (row) => row.v,
    },
    {
      name: "l (km/mol)	",
      selector: (row) => row.i,
    },
    {
      name: "Action",
      selector: (row) => (
        <button
          className={`btn ${
            imageData === row.video ? "btn-danger" : "btn-primary"
          }`}
          onClick={() => {
            changeImage(row.video);
          }}
        >
          Pilih
        </button>
      ),
    },
  ];

  useEffect(() => {
    dataFilter(dataVideo);

    // eslint-disable-next-line react-hooks/exhaustive-deps
  });
  return (
    <>
      <div className="container">
        <div className="row">
          <div className="col-12 mt-5 text-center">
            <h2 className="text-uppercase">{dataFiltered[0]?.senyawa}</h2>
          </div>
          <div className="col-md-6 mb-5 ">
            <div className="box-tanaman mt-5 mx-auto text-white">
              Vibrasi Molekul
            </div>
            <div className="mt-5">
              {loading ? (
                <div className="m-auto text-center">
                  <img src={imageLoading} alt="" className="img-fluid" />
                </div>
              ) : imageData === "" ? (
                <>
                  {" "}
                  <div className="row">
                    <div
                      className="col-12"
                      style={{
                        border: "1px solid black",
                        borderRadius: "20px",
                      }}
                    >
                      <div className="py-5">
                        <h5 className=" text-center">
                          Tekan bilangan gelombang untuk melihat vibrasi
                        </h5>
                      </div>
                    </div>
                  </div>
                </>
              ) : (
                // <div
                //   className="player-wrapper position-relative"
                //   style={{ top: "-300px" }}
                // >
                //   <ReactPlayer
                //     className="react-player"
                //     url={imageData}
                //     width="100%"
                //     height="100%"
                //     autoplay
                //   />
                // </div>
                <>
                  <img src={imageData} alt="" className="img-fluid" />
                </>
              )}
            </div>
          </div>
          <div className="col-md-6 pt-5">
            <div className="button mb-5">
              {dataFiltered?.map((item) => {
                return (
                  <a
                    href={`${item?.linkOutput}`}
                    download
                    className="btn btn-primary"
                  >
                    Unduh Output
                  </a>
                );
              })}
            </div>
            <DataTable columns={columns} data={dataRemap} pagination />
          </div>
          <div className="col-md-12">
            <div className="box-tanaman mb-5 mx-auto text-white">
              Spektra IR
            </div>
            {dataFiltered?.map((item) => {
              return (
                <img src={`${item.linkSpektra}`} alt="" className="img-fluid" />
              );
            })}
            {dataFiltered?.map((item) => {
              return (
                <div className="text-center">
                  <a
                    href={`${item.linkSpektra}`}
                    download
                    className="btn btn-primary"
                  >
                    Unduh Spektra IR
                  </a>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </>
  );
};

export default Detailspektra;
