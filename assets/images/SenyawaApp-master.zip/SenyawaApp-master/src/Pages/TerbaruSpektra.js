import React from "react";
import dataVideo from "../Data/DataVideo";

const TerbaruSpektra = () => {
  let dataLoop = dataVideo;
  return (
    <div>
      <div>
        <div className="container pt-5">
          <div className="row">
            <div
              className="col-md-4 offset-md-4"
              style={{ borderRadius: "20px", backgroundColor: "#353381" }}
            >
              <h1 className="text-center py-2 px-2 text-white">
                Spektra IR Terbaru
              </h1>
            </div>
            <div className="col-md-12">
              <table className="table table-striped mt-5">
                <thead>
                  <tr>
                    <th scope="col">No</th>
                    <th scope="col">Nama Senyawa</th>
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {dataLoop
                    .slice(0)
                    .reverse()
                    .slice(0, 10)
                    .map((item, index) => {
                      return (
                        <tr>
                          <th scope="row">{index + 1}</th>
                          <td>{item.senyawa}</td>
                          <td>
                            <a
                              className="btn btn-primary"
                              href={`/detail/spektra/${item.senyawa}`}
                            >
                              Detail
                            </a>
                          </td>
                        </tr>
                      );
                    })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TerbaruSpektra;
