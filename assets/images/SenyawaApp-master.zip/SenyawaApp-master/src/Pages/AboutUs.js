import React from "react";
import youtube from "../images/social/youtube.svg";
import twitter from "../images/social/twitter.svg";
import insta from "../images/social/instagram.svg";
import facebook from "../images/social/facebook.svg";
import email from "../images/social/email-svgrepo-com.svg";
import contribute from "../images/social/contributors.svg";
import { Link } from "react-router-dom";

export default function AboutUs() {
  return (
    <>
      {/* eslint-disable */}
      <div className="container">
        <div className="row my-5">
          <div className="col-md-12">
            <h3>History of Faculty</h3>
          </div>
          <div className="col-md-12 text-dark text-center">
            <img
              src="https://farmasi.ubaya.ac.id/wp-content/uploads/2020/03/history.jpg"
              className="img-fluid rounded"
              alt=""
            />
            <hr />
          </div>
          <div
            className="col-md-12 text-dark mt-4"
            style={{ textAlign: "justify" }}
          >
            <p>
              The Faculty of Pharmacy, University of Surabaya (FF UBAYA) was
              established in 1968. FF UBAYA is now managing 3 study programs,
              namely: Program Studi Sarjana Farmasi (PSSF) – Undergraduate
              Program; Program Studi Profesi Apoteker (PSPA) – Professional
              Program; dan Program Studi Magister Farmasi (PSMF) – Postgraduate
              Program with 2 majors, Clinical and Community Pharmacy (est. 2005)
              and Industrial Pharmacy (est. 2013). Up to this date, FF UBAYA has
              accomplished many achievements in national, regional, and world
              level. Starting form 1998, FF UBAYA has received accreditation
              form BAN-PT with A predicate. Since then, FF UBAYA has received
              such predicate 3 times in a row in 2004, 2011, and 2016 given by
              LAM-PTKES. PSPA Ubaya has also been re-accredited by LAM – PTKES
              and received a predicate in 2017 and followed by PSMF which
              received B predicate. Moving on to regional level, FF UBAYA has
              applied for accreditation from AUN-QA (Asian University Network
              Quality Assurance). In world level, FF UBAYA has also applied for
              accreditation from ACPE (Accreditation for Pharmacy Education).
              Upon these submissions, AUN-QA and ACPE have issued certificate of
              recognition. The Faculty of Pharmacy UBAYA organizes learning that
              facilitates students to develop themselves into Pharmacists who
              have knowledge, professional, social and communication skills, as
              well as competent and professional character and behavior of
              Pharmacists, to answer the needs of the community at the local and
              global level. Graduates’ quality control is maintained with a
              profile of graduates who have the ability to quickly adapt to the
              demands of information technology and be responsive to the needs
              of professional practice of pharmacy that has a linear correlation
              with the needs of the community so that they can meet the
              standards of cross-country Pharmacists and have the ability to
              compete at the global level and in accordance with the framework
              of the Indonesian National Qualifications (KKNI), the University
              of Surabaya Faculty of Pharmacy Development Orientation has two:
            </p>
            1. Development towards Pharmacy-Clinical-Community services by
            promoting Therapencilies Out Comes, Patient’s Quality of Life,
            services that are patient-centered, and rational treatment.
            <br />
            <br />
            2. Development of the Science and Industry field, especially the
            development of drugs, medicinal products, and cosmetics based on
            natural ingredients. The development of these two fields is expected
            to improve the quality of life of the community and increase the use
            of natural materials. The network of cooperation in learning,
            research, and community service with various domestic and foreign
            institutions has been going well and continues to grow.
            Quality-based and transparency-based management is expected to
            provide assurance for students and the community who interact with
            the University of Surabaya’s Faculty of Pharmacy in Tridharma
            services. UBAYA’s Pharmacy Faculty in the Undergraduate program has
            3 (three) interest groups, namely interest in Clinical and Community
            Pharmacy, Science-Technology-Industrial Pharmacy and Cosmetology
          </div>
          <div className="col-md-6 ps-5 my-3 d-flex align-items-center">
            <div>
              <div className="">
                <a
                  href="https://www.youtube.com/c/UbayaOfficial"
                  className="text-dark"
                  target="_blank"
                  style={{ textDecoration: "none" }}
                >
                  <img src={youtube} className="img-fluid" width="10%" alt="" />
                  <span className="ms-3">Youtube</span>
                </a>
              </div>

              <br />
              <div className="">
                <a
                  href="https://twitter.com/UbayaOfficial?s=20&t=_DxF31zbJLO1OPuNFxsAdA"
                  className="text-dark"
                  target="_blank"
                  style={{ textDecoration: "none" }}
                >
                  <img src={twitter} className="img-fluid" width="10%" alt="" />
                  <span className="ms-3">Twitter</span>
                </a>
              </div>

              <br />
              <div>
                <a
                  href="https://www.instagram.com/ubayaofficial"
                  target="_blank"
                  className="text-dark "
                  style={{ textDecoration: "none" }}
                >
                  <img src={insta} className="img-fluid" width="10%" alt="" />
                  <span className="ms-3">Instagram</span>
                </a>
              </div>

              <br />

              <div>
                <a
                  href="https://www.facebook.com/UbayaOfficial"
                  className="text-dark"
                  target="_blank"
                  style={{ textDecoration: "none" }}
                >
                  <img
                    src={facebook}
                    className="img-fluid"
                    width="10%"
                    alt=""
                  />
                  <span className="ms-3">Facebook</span>
                </a>
              </div>
              <br />
              <div>
                <a
                  href="mailto:titandigitalsoft@gmail.com"
                  className="text-dark"
                  target="_blank"
                  style={{ textDecoration: "none" }}
                >
                  <img src={email} className="img-fluid" width="10%" alt="" />
                  <span className="ms-3">titandigitalsoft@gmail.com</span>
                </a>
              </div>
              <br />
              <div>
                <Link
                  to="/contribute"
                  className="text-dark"
                  style={{ textDecoration: "none" }}
                >
                  <img
                    src={contribute}
                    className="img-fluid"
                    width="10%"
                    alt=""
                  />
                  <span className="ms-3">Contributors</span>
                </Link>
              </div>
            </div>
          </div>
          <div className="col-md-6">
            <div className="responsive-map-container">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3957.303180227706!2d112.76592321443654!3d-7.319800894717315!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2dd7fae3f29c4665%3A0x7536c23b4453a79!2sUniversity%20of%20Surabaya!5e0!3m2!1sen!2sid!4v1650239295398!5m2!1sen!2sid"
                width={600}
                height={450}
                style={{ border: 0 }}
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
