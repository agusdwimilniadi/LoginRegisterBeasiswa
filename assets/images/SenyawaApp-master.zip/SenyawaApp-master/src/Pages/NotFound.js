import React from "react";
import { useNavigate } from "react-router-dom";
export default function NotFound() {
  const navigate = useNavigate();
  return (
    <>
      <div
        className="empty-2-1 container mx-auto d-flex align-items-center justify-content-center flex-column"
        style={{ fontFamily: '"Poppins", sans-serif', height: "86vh" }}
      >
        <img
          className="main-img img-fluid"
          src="http://api.elements.buildwithangga.com/storage/files/2/assets/Empty%20State/EmptyState2/Empty-2-1.png"
          alt=""
        />
        <div className="text-center w-100">
          <h1 className="title-text text-dark mt-5">Data Tidak Ditemukan</h1>

          <div className="d-flex justify-content-center">
            <button
              className="btn btn-primary rounded text-white"
              onClick={() => {
                navigate("/");
              }}
            >
              Kembali ke halaman awal
            </button>
          </div>
        </div>
      </div>
    </>
  );
}
